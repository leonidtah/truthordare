package com.truthordare.app

/** Hands out items in random order and never repeats one until the whole list has been used. */
class Deck(private val items: List<String>) {
    private val queue = ArrayDeque<String>()

    fun next(): String {
        if (queue.isEmpty()) queue.addAll(items.shuffled())
        return queue.removeFirst()
    }
}

object Prompts {

    fun builtIn(lang: Lang, choice: Choice): List<String> = when (lang) {
        Lang.EN -> if (choice == Choice.TRUTH) truthsEn else daresEn
        Lang.FA -> if (choice == Choice.TRUTH) truthsFa else daresFa
    }

    val truthsEn = listOf(
        "What is the most embarrassing thing you've ever done in public?",
        "What's the biggest lie you've ever told?",
        "What's a secret talent nobody here knows about?",
        "Who in this room would you trust with your phone unlocked for an hour?",
        "What's the worst gift you've ever received, and who gave it to you?",
        "What's your most irrational fear?",
        "What's the last thing you searched on your phone?",
        "What's the most childish thing you still do?",
        "If you had to delete one app from your phone forever, which would it be?",
        "What's the most trouble you've ever gotten into?",
        "What's your guilty-pleasure song or show?",
        "Have you ever pretended to like a gift? What was it?",
        "What's the weirdest dream you remember?",
        "Who here do you think would survive the longest in a zombie apocalypse?",
        "What's one habit of yours that you know is annoying?",
        "What's the longest you've gone without showering?",
        "What was your most awkward date or hangout?",
        "What's something you've never told your parents?",
        "If you could swap lives with someone here for a day, who would it be?",
        "What's the silliest reason you've ever cried?",
        "What's the most expensive thing you've broken?",
        "Which person in this group do you text the most?",
        "What's the worst haircut or outfit you've ever had?",
        "What's a rule you always break?",
        "What's the most embarrassing thing in your camera roll right now?",
        "What's the first thing you'd do if you were invisible for a day?",
        "Have you ever laughed at a really bad moment? What happened?",
        "What's one thing you're really bad at but pretend you're good at?",
        "What's the strangest thing you've ever eaten?",
        "What nickname do you secretly hate?"
    )

    val daresEn = listOf(
        "Do your best impression of someone in this room until someone guesses who.",
        "Speak in an accent of your choice until your next turn.",
        "Do 15 jumping jacks right now.",
        "Let the group pick a word you must say at the end of every sentence until your next turn.",
        "Sing the chorus of any song, as loudly and dramatically as you can.",
        "Do your best runway walk across the room.",
        "Talk without closing your mouth for the next minute.",
        "Balance something on your head until your next turn.",
        "Let someone else send a harmless emoji to a contact of their choice from your phone.",
        "Act like a chicken for 20 seconds.",
        "Say the alphabet backwards as fast as you can.",
        "Try to lick your elbow.",
        "Do an over-the-top dramatic reading of the last text you sent.",
        "Hold a plank for 30 seconds.",
        "Make up a short rap about the person on your left.",
        "Dance with no music for 30 seconds.",
        "Pretend to be a news reporter and report on what's happening in this room.",
        "Walk like a penguin to the other side of the room and back.",
        "Close your eyes and let the group draw on your hand with a marker.",
        "Tell a joke. If nobody laughs, do 10 squats.",
        "Hop on one foot while reciting a nursery rhyme.",
        "Do your best evil villain laugh.",
        "Try to touch your nose with your tongue.",
        "Pretend you're a statue and hold still until your next turn comes up.",
        "Compliment every person in the group, one by one.",
        "Make a funny face and keep it for a full minute.",
        "Act out a famous movie scene without speaking and let the group guess.",
        "Speak only in questions until your next turn.",
        "Swap seats with the person the group chooses and stay there for the next round.",
        "Give the person to your right a one-minute shoulder rub."
    )

    val truthsFa = listOf(
        "شرم‌آورترین کاری که تا حالا جلوی جمع کرده‌ای چی بوده؟",
        "بزرگ‌ترین دروغی که تا حالا گفته‌ای چی بوده؟",
        "یک استعداد پنهان داری که کسی اینجا ازش خبر نداره؟ چیه؟",
        "اگه قرار باشه گوشی‌ات رو یک ساعت باز دست یکی از این جمع بدی، به کی اعتماد می‌کنی؟",
        "بدترین هدیه‌ای که تا حالا گرفته‌ای چی بوده و از طرف کی؟",
        "بی‌دلیل‌ترین ترس تو چیه؟",
        "آخرین چیزی که توی گوشی‌ات جستجو کردی چی بود؟",
        "بچگانه‌ترین کاری که هنوز انجام می‌دی چیه؟",
        "اگه مجبور بودی یک برنامه رو برای همیشه از گوشی‌ات پاک کنی، کدوم رو پاک می‌کردی؟",
        "بزرگ‌ترین دردسری که تا حالا برات پیش اومده چی بوده؟",
        "کدوم آهنگ یا سریال رو دوست داری ولی جلوی بقیه اعتراف نمی‌کنی؟",
        "تا حالا وانمود کرده‌ای هدیه‌ای رو دوست داری؟ اون هدیه چی بود؟",
        "عجیب‌ترین خوابی که یادت مونده چی بوده؟",
        "فکر می‌کنی توی این جمع کی تو آخرالزمان زامبی‌ها بیشتر دووم میاره؟",
        "کدوم عادت تو برای بقیه آزاردهنده‌ست و خودت هم می‌دونی؟",
        "طولانی‌ترین مدتی که حمام نرفته‌ای چقدر بوده؟",
        "ناجورترین قرار یا دورهمی عمرت چی بود؟",
        "چه چیزی هست که هیچ‌وقت به پدر و مادرت نگفته‌ای؟",
        "اگه می‌تونستی یک روز جای یکی از این جمع باشی، جای کی بودی؟",
        "الکی‌ترین دلیلی که براش گریه کرده‌ای چی بوده؟",
        "گران‌ترین چیزی که تا حالا شکسته‌ای چی بوده؟",
        "بیشتر از همه با کدوم یک از این جمع پیام‌بازی می‌کنی؟",
        "بدترین مدل مو یا لباسی که تا حالا داشته‌ای چی بوده؟",
        "کدوم قانون رو همیشه زیر پا می‌ذاری؟",
        "شرم‌آورترین چیزی که الان توی گالری گوشی‌ات هست چیه؟",
        "اگه یک روز نامرئی بودی، اولین کارت چی بود؟",
        "تا حالا سر یک موقع خیلی نامناسب خنده‌ات گرفته؟ چی شد؟",
        "تو چه کاری خیلی ضعیفی ولی وانمود می‌کنی خوبی؟",
        "عجیب‌ترین غذایی که تا حالا خورده‌ای چی بوده؟",
        "کدوم لقب رو پنهانی بیشتر از همه بدت میاد؟"
    )

    val daresFa = listOf(
        "ادای یکی از افراد این جمع رو دربیار تا بقیه حدس بزنن کیه.",
        "تا نوبت بعدی‌ات با لهجه‌ای که بقیه انتخاب می‌کنن حرف بزن.",
        "همین الان ۱۵ بار جامپینگ‌جک بزن.",
        "بقیه یک کلمه انتخاب می‌کنن؛ تا نوبت بعدی‌ات باید آخر هر جمله‌ات اون رو بگی.",
        "قسمت اصلی یک آهنگ رو با صدای بلند و با حالت نمایشی بخون.",
        "مثل مدل‌ها تا اون سر اتاق راه برو (کت‌واک).",
        "یک دقیقه بدون باز کردن دهانت حرف بزن.",
        "تا نوبت بعدی‌ات یک چیز رو روی سرت نگه دار.",
        "بذار یکی از جمع یک ایموجی بی‌خطر برای یکی از مخاطبین دلخواهش از گوشی تو بفرسته.",
        "۲۰ ثانیه مثل مرغ رفتار کن.",
        "حروف الفبای فارسی رو تا جایی که می‌تونی تند، از آخر به اول بگو.",
        "سعی کن آرنجت رو با زبانت لیس بزنی.",
        "آخرین پیامی که فرستاده‌ای رو با لحن خیلی نمایشی و دراماتیک بخون.",
        "۳۰ ثانیه پلانک بزن.",
        "یک رپ کوتاه درباره‌ی نفر سمت چپت بساز.",
        "۳۰ ثانیه بدون موسیقی برقص.",
        "مثل مجری خبر گزارش بده که الان اینجا چه خبره.",
        "مثل پنگوئن تا اون طرف اتاق برو و برگرد.",
        "چشم‌هات رو ببند و بذار بقیه با ماژیک روی دستت نقاشی بکشن.",
        "یک جوک بگو؛ اگه کسی نخندید ۱۰ بار اسکات بزن.",
        "روی یک پا بپر و همزمان یک شعر کودکانه بخون.",
        "بهترین خنده‌ی شرورانه‌ی فیلم‌ها رو اجرا کن.",
        "سعی کن با زبانت به نوک بینی‌ات برسی.",
        "مثل مجسمه بایست و تا نوبت بعدی‌ات تکون نخور.",
        "از تک‌تک افراد جمع یک تعریف بکن.",
        "یک دقیقه یک قیافه‌ی خنده‌دار بگیر و تغییرش نده.",
        "صحنه‌ای از یک فیلم معروف رو بدون حرف زدن بازی کن تا بقیه حدس بزنن.",
        "تا نوبت بعدی‌ات فقط به صورت سؤالی حرف بزن.",
        "جات رو با کسی که بقیه انتخاب می‌کنن عوض کن و تا یک دور بعد همون‌جا بشین.",
        "یک دقیقه به نفر سمت راستت ماساژ شونه بده."
    )
}
