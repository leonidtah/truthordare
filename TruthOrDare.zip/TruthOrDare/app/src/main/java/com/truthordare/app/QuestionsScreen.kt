package com.truthordare.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun QuestionsScreen(vm: GameViewModel, s: Strings) {
    var type by remember { mutableStateOf(Choice.TRUTH) }
    var catFilter by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Question?>(null) }
    var deleting by remember { mutableStateOf<Question?>(null) }
    var showCategories by remember { mutableStateOf(false) }

    val categories = vm.allCategories()
    val activeCat = catFilter?.takeIf { it in categories }
    val list = vm.questions.filter {
        it.lang == vm.lang && it.type == type && (activeCat == null || it.category == activeCat)
    }

    Column(modifier = Modifier.fillMaxSize().screenPadding()) {
        TopBar(title = s.questionsTitle, onBack = { vm.goBack() })
        Text(
            s.questionsHint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        ToggleButtons(
            options = listOf(s.truth, s.dare),
            selectedIndex = if (type == Choice.TRUTH) 0 else 1,
            onSelect = { type = if (it == 0) Choice.TRUTH else Choice.DARE }
        )
        Spacer(Modifier.height(8.dp))
        ChipRow {
            OptionChip(s.allCategories, activeCat == null) { catFilter = null }
            categories.forEach { c ->
                OptionChip(s.cat(c), activeCat == c) { catFilter = c }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            s.questionsCount(list.size),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { q ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 4.dp)) {
                        Text(
                            q.text,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                CategoryTag(s.cat(q.category))
                                DifficultyTag(q.difficulty, s.diff(q.difficulty))
                            }
                            IconButton(onClick = { editing = q }) {
                                Icon(Icons.Filled.Edit, contentDescription = s.edit)
                            }
                            IconButton(onClick = { deleting = q }) {
                                Icon(Icons.Filled.Delete, contentDescription = s.delete)
                            }
                        }
                    }
                }
            }
            item {
                TextButton(
                    onClick = { vm.restoreDefaultQuestions() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(s.restoreQuestions) }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SecondaryButton(
                s.categoriesButton,
                onClick = { showCategories = true },
                modifier = Modifier.weight(1f)
            )
            PrimaryButton(
                s.addQuestion,
                onClick = { adding = true },
                modifier = Modifier.weight(1f)
            )
        }
    }

    if (adding) {
        QuestionDialog(vm, s, initial = null, defaultType = type, onDismiss = { adding = false })
    }
    editing?.let { q ->
        QuestionDialog(vm, s, initial = q, defaultType = q.type, onDismiss = { editing = null })
    }
    deleting?.let { q ->
        ConfirmDialog(
            title = s.deleteTitle,
            body = q.text,
            confirm = s.delete,
            cancel = s.cancel,
            onConfirm = {
                vm.deleteQuestion(q.id)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
    if (showCategories) {
        CategoriesDialog(vm, s, onDismiss = { showCategories = false })
    }
}

@Composable
private fun QuestionDialog(
    vm: GameViewModel,
    s: Strings,
    initial: Question?,
    defaultType: Choice,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial?.text ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: defaultType) }
    var cat by remember { mutableStateOf(initial?.category ?: "general") }
    var diff by remember { mutableStateOf(initial?.difficulty ?: Difficulty.MEDIUM) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) s.addQuestion else s.editQuestion) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text(s.questionText) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 5
                )
                SectionLabel(s.typeLabel)
                ChipRow {
                    OptionChip(s.truth, type == Choice.TRUTH) { type = Choice.TRUTH }
                    OptionChip(s.dare, type == Choice.DARE) { type = Choice.DARE }
                }
                SectionLabel(s.categoriesLabel)
                ChipRow {
                    vm.allCategories().forEach { c ->
                        OptionChip(s.cat(c), cat == c) { cat = c }
                    }
                }
                SectionLabel(s.difficultyLabel)
                ChipRow {
                    Difficulty.values().forEach { d ->
                        OptionChip(s.diff(d), diff == d) { diff = d }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = text.isNotBlank(),
                onClick = {
                    if (initial == null) {
                        vm.addQuestion(type, cat, diff, text)
                    } else {
                        vm.updateQuestion(initial.id, type, cat, diff, text)
                    }
                    onDismiss()
                }
            ) { Text(s.saveButton) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(s.cancel) } }
    )
}

@Composable
private fun CategoriesDialog(vm: GameViewModel, s: Strings, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s.categoriesTitle) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(s.newCategoryLabel) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(onClick = {
                        vm.addCategory(name)
                        name = ""
                    }) {
                        Icon(Icons.Filled.Add, contentDescription = s.addButton)
                    }
                }
                if (vm.customCategories.isEmpty()) {
                    Text(
                        s.noCustomCategories,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    vm.customCategories.toList().forEach { c ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(c, modifier = Modifier.weight(1f))
                            IconButton(onClick = { vm.removeCategory(c) }) {
                                Icon(Icons.Filled.Delete, contentDescription = s.delete)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(s.done) } }
    )
}
