package com.truthordare.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SetupScreen(vm: GameViewModel, s: Strings) {
    var input by remember { mutableStateOf("") }
    val addPlayer = {
        vm.addNames(input)
        input = ""
        vm.sfx(Sfx.TAP)
    }
    val canStart = vm.mode == GameMode.EVERYONE || vm.names.size >= 2

    Column(modifier = Modifier.fillMaxSize().screenPadding()) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        s.appTitle,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { vm.go(Screen.SETTINGS) }) {
                        Icon(Icons.Filled.Settings, contentDescription = s.settingsTitle)
                    }
                }
            }
            item {
                Text(s.setupHint, style = MaterialTheme.typography.bodyMedium)
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text(s.playerName) },
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(onDone = { addPlayer() })
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(onClick = { addPlayer() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Filled.Add, contentDescription = s.addPlayer)
                    }
                }
            }
            item {
                Text(
                    s.playersCount(vm.names.size),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            items(vm.names, key = { it }) { name ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(name, style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { vm.removeName(name) }) {
                            Icon(Icons.Filled.Close, contentDescription = s.removePlayer(name))
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Spacer(Modifier.height(6.dp))
                    SectionLabel(s.modeTitle)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SelectableCard(
                            selected = vm.mode == GameMode.CLASSIC,
                            title = s.modeClassic,
                            desc = s.modeClassicDesc,
                            onClick = { vm.selectMode(GameMode.CLASSIC) },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        )
                        SelectableCard(
                            selected = vm.mode == GameMode.EVERYONE,
                            title = s.modeEveryone,
                            desc = s.modeEveryoneDesc,
                            onClick = { vm.selectMode(GameMode.EVERYONE) },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        )
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Spacer(Modifier.height(6.dp))
                    SectionLabel(s.filtersTitle)
                    Text(s.categoriesLabel, style = MaterialTheme.typography.labelLarge)
                    ChipRow {
                        vm.allCategories().forEach { c ->
                            OptionChip(
                                label = s.cat(c),
                                selected = c !in vm.excludedCats,
                                onClick = { vm.toggleCategory(c) }
                            )
                        }
                    }
                    Text(s.difficultyLabel, style = MaterialTheme.typography.labelLarge)
                    ChipRow {
                        Difficulty.values().forEach { d ->
                            OptionChip(
                                label = s.diff(d),
                                selected = d !in vm.excludedDiffs,
                                onClick = { vm.toggleDifficulty(d) }
                            )
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SecondaryButton(
                            s.questionsButton,
                            onClick = { vm.go(Screen.QUESTIONS) },
                            modifier = Modifier.weight(1f)
                        )
                        SecondaryButton(
                            s.punishmentsButton,
                            onClick = { vm.go(Screen.PUNISHMENTS) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        if (!canStart) {
            Text(
                s.needTwo,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        PrimaryButton(s.startGame, onClick = { vm.start(vm.mode) }, enabled = canStart)
    }
}
