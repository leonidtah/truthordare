package com.truthordare.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: GameViewModel = viewModel()
            val s = stringsFor(vm.lang)
            val dark = when (vm.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }
            val direction = if (vm.lang == Lang.FA) LayoutDirection.Rtl else LayoutDirection.Ltr

            // Keep the status/navigation bar icons readable when the in-app theme differs from the system one.
            SideEffect {
                val transparent = android.graphics.Color.TRANSPARENT
                enableEdgeToEdge(
                    statusBarStyle = if (dark) {
                        SystemBarStyle.dark(transparent)
                    } else {
                        SystemBarStyle.light(transparent, transparent)
                    },
                    navigationBarStyle = if (dark) {
                        SystemBarStyle.dark(transparent)
                    } else {
                        SystemBarStyle.light(transparent, transparent)
                    }
                )
            }

            CompositionLocalProvider(LocalLayoutDirection provides direction) {
                TruthOrDareTheme(dark = dark) {
                    val extra = LocalExtra.current
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.onBackground
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Brush.verticalGradient(listOf(extra.bgTop, extra.bgBottom)))
                        ) {
                            BackHandler(enabled = vm.screen != Screen.SETUP) { vm.goBack() }
                            Crossfade(targetState = vm.screen, label = "screen") { screen ->
                                when (screen) {
                                    Screen.SETUP -> SetupScreen(vm, s)
                                    Screen.PLAYING -> ClassicScreen(vm, s)
                                    Screen.EVERYONE -> EveryoneScreen(vm, s)
                                    Screen.WHEEL -> WheelScreen(vm, s)
                                    Screen.QUESTIONS -> QuestionsScreen(vm, s)
                                    Screen.PUNISHMENTS -> PunishmentsScreen(vm, s)
                                    Screen.SETTINGS -> SettingsScreen(vm, s)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
