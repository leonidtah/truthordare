package com.truthordare.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

private val TruthColor = Color(0xFF2563EB)
private val DareColor = Color(0xFFDC2626)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: GameViewModel = viewModel()
            val s = stringsFor(vm.lang)
            val direction = if (vm.lang == Lang.FA) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides direction) {
                TruthOrDareTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        BackHandler(enabled = vm.screen != Screen.SETUP) { vm.backToSetup() }
                        when (vm.screen) {
                            Screen.SETUP -> SetupScreen(vm, s)
                            Screen.PLAYING -> GameScreen(vm, s)
                            Screen.QUESTIONS -> QuestionsScreen(vm, s)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TruthOrDareTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = Color(0xFFC4B5FD), onPrimary = Color(0xFF2E1065))
    } else {
        lightColorScheme(primary = Color(0xFF6D28D9))
    }
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
fun SetupScreen(vm: GameViewModel, s: Strings) {
    var input by remember { mutableStateOf("") }
    val addPlayer = {
        vm.addNames(input)
        input = ""
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                s.appTitle,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(
                onClick = {
                    vm.setLanguage(if (vm.lang == Lang.FA) Lang.EN else Lang.FA)
                }
            ) {
                Text(s.languageButton)
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(s.setupHint, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text(s.playerName) },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { addPlayer() })
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { addPlayer() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.Add, contentDescription = s.addPlayer)
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(s.playersCount(vm.names.size), style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(vm.names, key = { it }) { name ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(name, style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { vm.removeName(name) }) {
                            Icon(Icons.Filled.Close, contentDescription = s.removePlayer(name))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        if (vm.names.size < 2) {
            Text(
                s.needTwo,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        OutlinedButton(
            onClick = { vm.openQuestions() },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(s.manageQuestions)
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { vm.start() },
            enabled = vm.names.size >= 2,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(s.startGame, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun QuestionsScreen(vm: GameViewModel, s: Strings) {
    var type by remember { mutableStateOf(Choice.TRUTH) }
    var input by remember { mutableStateOf("") }
    val addQuestion = {
        vm.addCustom(type, input)
        input = ""
    }
    val list = vm.customPrompts.filter { it.lang == vm.lang && it.choice == type }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(20.dp)
    ) {
        TextButton(onClick = { vm.backToSetup() }) { Text(s.back) }
        Text(s.questionsTitle, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(s.questionsHint, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TypeButton(s.truth, TruthColor, selected = type == Choice.TRUTH) { type = Choice.TRUTH }
            TypeButton(s.dare, DareColor, selected = type == Choice.DARE) { type = Choice.DARE }
        }
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3,
            label = { Text(if (type == Choice.TRUTH) s.newTruthLabel else s.newDareLabel) }
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { addQuestion() },
            enabled = input.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(s.addButton, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))

        if (list.isEmpty()) {
            Text(s.noneYet, style = MaterialTheme.typography.bodyMedium)
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.text }) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            p.text,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyLarge
                        )
                        IconButton(onClick = { vm.removeCustom(p) }) {
                            Icon(Icons.Filled.Close, contentDescription = s.removeQuestion)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.TypeButton(
    label: String,
    color: Color,
    selected: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    val modifier = Modifier
        .weight(1f)
        .height(48.dp)
    if (selected) {
        Button(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White)
        ) {
            Text(label, fontWeight = FontWeight.Bold)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier, shape = shape) {
            Text(label)
        }
    }
}

@Composable
fun GameScreen(vm: GameViewModel, s: Strings) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.backToSetup() }) { Text(s.editPlayers) }
            Text(s.playing(vm.names.size), style = MaterialTheme.typography.labelLarge)
        }

        Spacer(Modifier.weight(1f))

        val prompt = vm.prompt
        val choice = vm.choice

        when {
            vm.spinning -> {
                Text(s.picking, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                Text(
                    vm.spinDisplay,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            prompt == null || choice == null -> {
                Text(s.yourTurn, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    vm.currentPlayer,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(32.dp))
                Text(s.truthOrDare, style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ChoiceButton(s.truth, TruthColor) { vm.choose(Choice.TRUTH) }
                    ChoiceButton(s.dare, DareColor) { vm.choose(Choice.DARE) }
                }
            }

            else -> {
                val label = if (choice == Choice.TRUTH) s.truth else s.dare
                val color = if (choice == Choice.TRUTH) TruthColor else DareColor
                Text(
                    "${vm.currentPlayer} · ${label.uppercase()}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = color)
                ) {
                    Text(
                        prompt,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(24.dp))
                OutlinedButton(
                    onClick = { vm.newPrompt() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(s.anotherOne)
                }
            }
        }

        Spacer(Modifier.weight(1f))

        if (!vm.spinning) {
            Button(
                onClick = { vm.pickNext() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    if (vm.prompt == null) s.skipTurn else s.doneNext,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun RowScope.ChoiceButton(label: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .weight(1f)
            .height(72.dp),
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White)
    ) {
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}
