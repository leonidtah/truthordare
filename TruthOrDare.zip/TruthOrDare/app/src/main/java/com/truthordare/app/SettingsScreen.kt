package com.truthordare.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(vm: GameViewModel, s: Strings) {
    val themes = ThemeMode.values().toList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .screenPadding()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TopBar(title = s.settingsTitle, onBack = { vm.goBack() })

        SectionLabel(s.languageLabel)
        ToggleButtons(
            options = listOf("English", "فارسی"),
            selectedIndex = if (vm.lang == Lang.EN) 0 else 1,
            onSelect = { vm.setLanguage(if (it == 0) Lang.EN else Lang.FA) }
        )

        SectionLabel(s.themeLabel)
        ToggleButtons(
            options = listOf(s.themeSystem, s.themeLight, s.themeDark),
            selectedIndex = themes.indexOf(vm.themeMode),
            onSelect = { vm.setTheme(themes[it]) }
        )

        SectionLabel(s.soundLabel)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        s.soundLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        s.soundDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = vm.soundOn, onCheckedChange = { vm.setSound(it) })
            }
        }
    }
}
