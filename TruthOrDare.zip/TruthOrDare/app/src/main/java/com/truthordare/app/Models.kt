package com.truthordare.app

import java.util.UUID

enum class Lang { EN, FA }

enum class Choice { TRUTH, DARE }

enum class Difficulty { EASY, MEDIUM, HARD }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class GameMode { CLASSIC, EVERYONE }

enum class Screen { SETUP, PLAYING, EVERYONE, WHEEL, QUESTIONS, PUNISHMENTS, SETTINGS }

data class Question(
    val id: String,
    val lang: Lang,
    val type: Choice,
    val category: String,
    val difficulty: Difficulty,
    val text: String
)

data class Punishment(
    val id: String,
    val lang: Lang,
    val text: String
)

object Categories {
    /** Keys of the built-in categories. Their display names live in Strings. */
    val builtIn = listOf("general", "funny", "embarrassing", "friends", "active", "creative", "personal")
}

fun newId(): String = UUID.randomUUID().toString()
