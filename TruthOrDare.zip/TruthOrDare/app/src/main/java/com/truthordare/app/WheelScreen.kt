package com.truthordare.app

import android.os.SystemClock
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private val WheelColors = listOf(
    Color(0xFF7C3AED),
    Color(0xFF2563EB),
    Color(0xFF0D9488),
    Color(0xFF16A34A),
    Color(0xFFD97706),
    Color(0xFFDC2626),
    Color(0xFFDB2777),
    Color(0xFF4F46E5)
)

/** Which segment is under the pointer (top of the wheel) for a given rotation. */
private fun indexAt(rotation: Float, n: Int): Int {
    val a = ((-rotation % 360f) + 360f) % 360f
    return (a / (360f / n)).toInt().coerceIn(0, n - 1)
}

@Composable
fun WheelScreen(vm: GameViewModel, s: Strings) {
    val items = vm.punishments.filter { it.lang == vm.lang }
    var rotation by remember { mutableStateOf(0f) }
    var spinning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val pointerColor = MaterialTheme.colorScheme.onBackground
    val ringColor = MaterialTheme.colorScheme.surface
    val hubColor = MaterialTheme.colorScheme.primary

    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textAlign = android.graphics.Paint.Align.LEFT
        }
    }

    fun spin() {
        if (spinning || items.size < 2) return
        spinning = true
        result = null
        val list = items
        scope.launch {
            val n = list.size
            val sweep = 360f / n
            val target = Random.nextInt(n)
            val within = 0.15f + Random.nextFloat() * 0.7f
            val aTarget = (target + within) * sweep
            val desired = ((360f - aTarget) % 360f + 360f) % 360f
            val cur = ((rotation % 360f) + 360f) % 360f
            val delta = ((desired - cur) + 360f) % 360f
            val start = rotation
            val end = start + 360f * (5 + Random.nextInt(3)) + delta

            var lastIdx = -1
            var lastTick = 0L
            animate(
                initialValue = start,
                targetValue = end,
                animationSpec = tween(durationMillis = 4300, easing = CubicBezierEasing(0.1f, 0.6f, 0.15f, 1f))
            ) { value, _ ->
                rotation = value
                val idx = indexAt(value, n)
                if (idx != lastIdx) {
                    lastIdx = idx
                    val now = SystemClock.uptimeMillis()
                    if (now - lastTick > 70) {
                        lastTick = now
                        vm.sfx(Sfx.TICK)
                    }
                }
            }
            rotation = end
            result = list[indexAt(end, n)].text
            vm.sfx(Sfx.WIN)
            spinning = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .screenPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopBar(title = s.wheelTitle, onBack = { vm.goBack() })

        if (items.size < 2) {
            Spacer(Modifier.weight(1f))
            Text(
                s.wheelNeedTwo,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            SecondaryButton(s.editPunishments, onClick = { vm.go(Screen.PUNISHMENTS) })
            Spacer(Modifier.weight(1f))
        } else {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                ) {
                    val n = items.size
                    val sweep = 360f / n
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.minDimension / 2f * 0.84f
                    val topLeft = Offset(center.x - radius, center.y - radius)
                    val arcSize = Size(radius * 2f, radius * 2f)

                    // outer ring
                    drawCircle(color = ringColor, radius = radius + 7.dp.toPx(), center = center)

                    // segments
                    for (i in 0 until n) {
                        var ci = i % WheelColors.size
                        if (i == n - 1 && n > 1 && ci == 0) ci = WheelColors.size / 2
                        drawArc(
                            color = WheelColors[ci],
                            startAngle = -90f + i * sweep + rotation,
                            sweepAngle = sweep,
                            useCenter = true,
                            topLeft = topLeft,
                            size = arcSize
                        )
                        drawArc(
                            color = Color.White.copy(alpha = 0.55f),
                            startAngle = -90f + i * sweep + rotation,
                            sweepAngle = sweep,
                            useCenter = true,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }

                    // labels
                    val maxW = radius * 0.62f
                    val textSizePx = min(radius * 0.11f, (2f * PI.toFloat() * radius * 0.6f / n) * 0.7f)
                    paint.textSize = textSizePx
                    for (i in 0 until n) {
                        val mid = -90f + (i + 0.5f) * sweep + rotation
                        var label = items[i].text
                        val fit = paint.breakText(label, true, maxW, null)
                        if (fit < label.length) {
                            label = label.substring(0, max(1, fit - 1)) + "…"
                        }
                        rotate(degrees = mid, pivot = center) {
                            drawContext.canvas.nativeCanvas.drawText(
                                label,
                                center.x + radius * 0.2f,
                                center.y + textSizePx * 0.35f,
                                paint
                            )
                        }
                    }

                    // hub
                    drawCircle(color = Color.White, radius = radius * 0.1f, center = center)
                    drawCircle(color = hubColor, radius = radius * 0.05f, center = center)

                    // pointer at the top
                    val tri = Path().apply {
                        moveTo(center.x, center.y - radius + 12.dp.toPx())
                        lineTo(center.x - 14.dp.toPx(), center.y - radius - 16.dp.toPx())
                        lineTo(center.x + 14.dp.toPx(), center.y - radius - 16.dp.toPx())
                        close()
                    }
                    drawPath(path = tri, color = pointerColor)
                }
            }

            Spacer(Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 96.dp),
                contentAlignment = Alignment.Center
            ) {
                val r = result
                when {
                    spinning -> Text(
                        s.spinning,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    r != null -> Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                s.yourPunishment,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                r,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    else -> Spacer(Modifier.height(1.dp))
                }
            }

            Spacer(Modifier.height(8.dp))
            PrimaryButton(
                text = if (result == null) s.spin else s.spinAgain,
                onClick = { spin() },
                enabled = !spinning
            )
            Spacer(Modifier.height(8.dp))
            SecondaryButton(s.done, onClick = { vm.goBack() })
        }
    }
}
