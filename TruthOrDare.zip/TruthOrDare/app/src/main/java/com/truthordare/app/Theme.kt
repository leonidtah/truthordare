package com.truthordare.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Colors the Material scheme has no slot for. */
@Immutable
data class Extra(
    val truth: Color,
    val dare: Color,
    val bgTop: Color,
    val bgBottom: Color
)

private val LightExtra = Extra(
    truth = Color(0xFF2563EB),
    dare = Color(0xFFE11D48),
    bgTop = Color(0xFFF7F4FF),
    bgBottom = Color(0xFFE6DDFF)
)

private val DarkExtra = Extra(
    truth = Color(0xFF3B82F6),
    dare = Color(0xFFF43F5E),
    bgTop = Color(0xFF0E0A1F),
    bgBottom = Color(0xFF1F1445)
)

val LocalExtra = staticCompositionLocalOf { LightExtra }

private val LightScheme = lightColorScheme(
    primary = Color(0xFF6D28D9),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE9FE),
    onPrimaryContainer = Color(0xFF2E1065),
    secondary = Color(0xFFDB2777),
    onSecondary = Color.White,
    background = Color(0xFFF7F4FF),
    onBackground = Color(0xFF1B1530),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1530),
    surfaceVariant = Color(0xFFEDE8FB),
    onSurfaceVariant = Color(0xFF4B4466),
    outline = Color(0xFFB8AEDB)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFA78BFA),
    onPrimary = Color(0xFF1E1146),
    primaryContainer = Color(0xFF3B2A78),
    onPrimaryContainer = Color(0xFFEDE9FE),
    secondary = Color(0xFFF472B6),
    onSecondary = Color(0xFF3B0A24),
    background = Color(0xFF0E0A1F),
    onBackground = Color(0xFFF3EFFF),
    surface = Color(0xFF1A1433),
    onSurface = Color(0xFFF3EFFF),
    surfaceVariant = Color(0xFF282048),
    onSurfaceVariant = Color(0xFFC9C0E8),
    outline = Color(0xFF5B4F8A)
)

@Composable
fun TruthOrDareTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalExtra provides (if (dark) DarkExtra else LightExtra)) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            content = content
        )
    }
}

fun difficultyColor(d: Difficulty): Color = when (d) {
    Difficulty.EASY -> Color(0xFF16A34A)
    Difficulty.MEDIUM -> Color(0xFFD97706)
    Difficulty.HARD -> Color(0xFFDC2626)
}
