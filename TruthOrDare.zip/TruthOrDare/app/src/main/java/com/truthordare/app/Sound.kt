package com.truthordare.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

enum class Sfx { TAP, TICK, SELECT, PICK, WIN }

/**
 * Tiny synthesized sound effects: soft sine tones with a gentle fade, kept quiet on purpose.
 * Nothing is bundled as audio files; the sounds are generated the first time they are needed.
 */
class SoundPlayer {

    @Volatile
    var enabled: Boolean = true

    private val rate = 22050
    private val exec = Executors.newSingleThreadScheduledExecutor()
    private val cache = HashMap<Sfx, ShortArray>() // only touched from the executor thread

    fun play(sfx: Sfx) {
        if (!enabled) return
        try {
            exec.execute {
                try {
                    val data = cache.getOrPut(sfx) { build(sfx) }
                    val track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(rate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(data.size * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()
                    track.write(data, 0, data.size)
                    track.play()
                    val ms = data.size * 1000L / rate
                    exec.schedule(Runnable { runCatching { track.release() } }, ms + 150, TimeUnit.MILLISECONDS)
                } catch (e: Throwable) {
                    // Sound is a nicety; never let it crash the game.
                }
            }
        } catch (e: Throwable) {
            // executor already shut down
        }
    }

    fun release() {
        runCatching { exec.shutdownNow() }
    }

    private fun build(sfx: Sfx): ShortArray = when (sfx) {
        Sfx.TAP -> tone(600.0, 70, 0.20)
        Sfx.TICK -> tone(900.0, 28, 0.12)
        Sfx.SELECT -> concat(tone(494.0, 90, 0.20), tone(659.0, 160, 0.20))
        Sfx.PICK -> concat(tone(523.0, 100, 0.22), tone(784.0, 220, 0.22))
        Sfx.WIN -> concat(tone(523.0, 110, 0.20), tone(659.0, 110, 0.20), tone(784.0, 240, 0.20))
    }

    private fun tone(freq: Double, ms: Int, amp: Double): ShortArray {
        val n = rate * ms / 1000
        val out = ShortArray(n)
        val attack = rate * 0.008
        for (i in 0 until n) {
            val t = i.toDouble() / rate
            val env = min(1.0, i / attack) * exp(-5.0 * i / n)
            val wave = sin(2.0 * PI * freq * t) + 0.25 * sin(2.0 * PI * freq * 2.0 * t)
            out[i] = (wave / 1.25 * env * amp * 32767.0).toInt().toShort()
        }
        return out
    }

    private fun concat(vararg parts: ShortArray): ShortArray {
        var total = 0
        for (p in parts) total += p.size
        val out = ShortArray(total)
        var pos = 0
        for (p in parts) {
            p.copyInto(out, pos)
            pos += p.size
        }
        return out
    }
}
