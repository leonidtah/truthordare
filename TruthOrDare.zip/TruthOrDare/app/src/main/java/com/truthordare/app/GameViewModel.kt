package com.truthordare.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

enum class Lang { EN, FA }

enum class Screen { SETUP, PLAYING, QUESTIONS }

enum class Choice { TRUTH, DARE }

data class CustomPrompt(val lang: Lang, val choice: Choice, val text: String)

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("truth_or_dare", Context.MODE_PRIVATE)

    val names = mutableStateListOf<String>()
    val customPrompts = mutableStateListOf<CustomPrompt>()

    var lang by mutableStateOf(Lang.EN)
        private set
    var screen by mutableStateOf(Screen.SETUP)
        private set
    var currentPlayer by mutableStateOf("")
        private set
    var choice by mutableStateOf<Choice?>(null)
        private set
    var prompt by mutableStateOf<String?>(null)
        private set
    var spinning by mutableStateOf(false)
        private set
    var spinDisplay by mutableStateOf("")
        private set

    private val decks = mutableMapOf<Pair<Lang, Choice>, Deck>()

    // Everyone gets a turn before anyone gets a second one.
    private val bag = ArrayDeque<String>()
    private var lastPlayer: String? = null

    init {
        load()
    }

    // ---------- language ----------

    fun setLanguage(l: Lang) {
        lang = l
        prefs.edit().putString("lang", l.name).apply()
    }

    // ---------- players ----------

    /** Accepts one name or several separated by commas (English or Persian), semicolons or new lines. */
    fun addNames(raw: String) {
        raw.split(',', '،', ';', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { candidate ->
                if (names.none { it.equals(candidate, ignoreCase = true) }) {
                    names.add(candidate)
                }
            }
        saveNames()
    }

    fun removeName(name: String) {
        names.remove(name)
        saveNames()
    }

    // ---------- custom questions ----------

    fun addCustom(choice: Choice, raw: String) {
        val text = raw.replace('\n', ' ').trim()
        if (text.isEmpty()) return
        val exists = customPrompts.any {
            it.lang == lang && it.choice == choice && it.text.equals(text, ignoreCase = true)
        }
        if (exists) return
        customPrompts.add(CustomPrompt(lang, choice, text))
        decks.remove(lang to choice)
        saveCustom()
    }

    fun removeCustom(p: CustomPrompt) {
        customPrompts.remove(p)
        decks.remove(p.lang to p.choice)
        saveCustom()
    }

    fun openQuestions() {
        screen = Screen.QUESTIONS
    }

    // ---------- game flow ----------

    fun start() {
        if (names.size < 2) return
        bag.clear()
        lastPlayer = null
        screen = Screen.PLAYING
        pickNext()
    }

    fun pickNext() {
        if (spinning || names.isEmpty()) return
        viewModelScope.launch {
            spinning = true
            choice = null
            prompt = null

            if (bag.isEmpty()) refillBag()
            val next = bag.removeFirst()

            // Quick "slot machine" effect that slows down before landing on the winner.
            repeat(14) { step ->
                spinDisplay = names.random()
                delay(60L + step * 14L)
            }
            currentPlayer = next
            lastPlayer = next
            spinning = false
        }
    }

    fun choose(c: Choice) {
        choice = c
        prompt = deckFor(c).next()
    }

    fun newPrompt() {
        choice?.let { choose(it) }
    }

    fun backToSetup() {
        screen = Screen.SETUP
        choice = null
        prompt = null
        spinning = false
        bag.clear()
        lastPlayer = null
    }

    // ---------- internals ----------

    private fun deckFor(c: Choice): Deck = decks.getOrPut(lang to c) {
        val own = customPrompts
            .filter { it.lang == lang && it.choice == c }
            .map { it.text }
        Deck(Prompts.builtIn(lang, c) + own)
    }

    private fun refillBag() {
        val shuffled = names.shuffled().toMutableList()
        // Avoid the same person going twice in a row when a new round starts.
        if (shuffled.size > 1 && shuffled.first() == lastPlayer) {
            val last = shuffled.lastIndex
            val tmp = shuffled[0]
            shuffled[0] = shuffled[last]
            shuffled[last] = tmp
        }
        bag.addAll(shuffled)
    }

    private fun saveNames() {
        prefs.edit().putString("names", JSONArray(names.toList()).toString()).apply()
    }

    private fun saveCustom() {
        val arr = JSONArray()
        customPrompts.forEach { p ->
            arr.put(
                JSONObject()
                    .put("l", p.lang.name)
                    .put("c", p.choice.name)
                    .put("t", p.text)
            )
        }
        prefs.edit().putString("custom", arr.toString()).apply()
    }

    private fun load() {
        lang = prefs.getString("lang", null)
            ?.let { saved -> Lang.values().firstOrNull { it.name == saved } }
            ?: if (Locale.getDefault().language == "fa") Lang.FA else Lang.EN

        runCatching {
            val arr = JSONArray(prefs.getString("names", "[]"))
            for (i in 0 until arr.length()) names.add(arr.getString(i))
        }
        runCatching {
            val arr = JSONArray(prefs.getString("custom", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                customPrompts.add(
                    CustomPrompt(
                        Lang.valueOf(o.getString("l")),
                        Choice.valueOf(o.getString("c")),
                        o.getString("t")
                    )
                )
            }
        }
    }
}
