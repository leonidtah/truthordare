package com.truthordare.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("truth_or_dare", Context.MODE_PRIVATE)
    private val sound = SoundPlayer()

    // ---------- saved data ----------
    val names = mutableStateListOf<String>()
    val questions = mutableStateListOf<Question>()
    val punishments = mutableStateListOf<Punishment>()
    val customCategories = mutableStateListOf<String>()

    // ---------- settings ----------
    var lang by mutableStateOf(Lang.EN)
        private set
    var themeMode by mutableStateOf(ThemeMode.SYSTEM)
        private set
    var soundOn by mutableStateOf(true)
        private set
    var excludedCats by mutableStateOf<Set<String>>(emptySet())
        private set
    var excludedDiffs by mutableStateOf<Set<Difficulty>>(emptySet())
        private set
    var mode by mutableStateOf(GameMode.CLASSIC)
        private set

    // ---------- game state ----------
    var screen by mutableStateOf(Screen.SETUP)
        private set
    var currentPlayer by mutableStateOf("")
        private set
    var choice by mutableStateOf<Choice?>(null)
        private set
    var prompt by mutableStateOf<Question?>(null)
        private set
    var spinning by mutableStateOf(false)
        private set
    var spinDisplay by mutableStateOf("")
        private set
    var everyoneQuestion by mutableStateOf<Question?>(null)
        private set
    var everyoneCount by mutableStateOf(0)
        private set

    // Everyone gets a turn before anyone gets a second one.
    private val bag = ArrayDeque<String>()
    private var lastPlayer: String? = null
    private val used = mutableSetOf<String>()
    private var wheelReturn = Screen.SETUP

    init {
        load()
    }

    // ================= navigation =================

    fun go(s: Screen) {
        screen = s
    }

    fun goBack() {
        when (screen) {
            Screen.WHEEL -> screen = wheelReturn
            Screen.PLAYING, Screen.EVERYONE -> backToSetup()
            else -> screen = Screen.SETUP
        }
    }

    fun openWheel() {
        wheelReturn = screen
        screen = Screen.WHEEL
    }

    fun backToSetup() {
        screen = Screen.SETUP
        choice = null
        prompt = null
        spinning = false
        everyoneQuestion = null
        bag.clear()
        lastPlayer = null
    }

    fun sfx(s: Sfx) {
        sound.play(s)
    }

    // ================= settings =================

    fun setLanguage(l: Lang) {
        lang = l
        used.clear()
        prefs.edit().putString("lang", l.name).apply()
    }

    fun setTheme(t: ThemeMode) {
        themeMode = t
        prefs.edit().putString("theme", t.name).apply()
    }

    fun setSound(on: Boolean) {
        soundOn = on
        sound.enabled = on
        prefs.edit().putBoolean("sound", on).apply()
        if (on) sound.play(Sfx.TAP)
    }

    fun selectMode(m: GameMode) {
        mode = m
    }

    fun allCategories(): List<String> = Categories.builtIn + customCategories

    fun toggleCategory(key: String) {
        val ex = excludedCats
        val next = if (key in ex) ex - key else ex + key
        // At least one category must stay selected.
        if (allCategories().all { it in next }) return
        excludedCats = next
        saveFilters()
    }

    fun toggleDifficulty(d: Difficulty) {
        val ex = excludedDiffs
        val next = if (d in ex) ex - d else ex + d
        if (Difficulty.values().all { it in next }) return
        excludedDiffs = next
        saveFilters()
    }

    // ================= players =================

    /** Accepts one name or several separated by commas (English or Persian), semicolons or new lines. */
    fun addNames(raw: String) {
        raw.split(',', '،', ';', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { candidate ->
                if (names.none { it.equals(candidate, ignoreCase = true) }) {
                    names.add(candidate)
                }
            }
        saveNames()
    }

    fun removeName(name: String) {
        names.remove(name)
        saveNames()
    }

    // ================= questions =================

    fun addQuestion(type: Choice, category: String, difficulty: Difficulty, text: String) {
        val t = text.replace('\n', ' ').trim()
        if (t.isEmpty()) return
        questions.add(0, Question(newId(), lang, type, category, difficulty, t))
        saveQuestions()
    }

    fun updateQuestion(id: String, type: Choice, category: String, difficulty: Difficulty, text: String) {
        val i = questions.indexOfFirst { it.id == id }
        if (i < 0) return
        val t = text.replace('\n', ' ').trim()
        if (t.isEmpty()) return
        questions[i] = questions[i].copy(type = type, category = category, difficulty = difficulty, text = t)
        saveQuestions()
    }

    fun deleteQuestion(id: String) {
        questions.removeAll { it.id == id }
        saveQuestions()
    }

    /** Brings back built-in questions (current language) that were deleted. Edited ones are left alone. */
    fun restoreDefaultQuestions() {
        val have = questions.map { it.id }.toSet()
        val missing = Seeds.questions().filter { it.lang == lang && it.id !in have }
        questions.addAll(missing)
        saveQuestions()
    }

    fun addCategory(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        if (allCategories().any { it.equals(n, ignoreCase = true) }) return
        customCategories.add(n)
        saveCategories()
    }

    fun removeCategory(name: String) {
        customCategories.remove(name)
        for (i in questions.indices) {
            if (questions[i].category == name) {
                questions[i] = questions[i].copy(category = "general")
            }
        }
        excludedCats = excludedCats - name
        saveCategories()
        saveQuestions()
        saveFilters()
    }

    // ================= punishments =================

    fun addPunishment(text: String) {
        val t = text.replace('\n', ' ').trim()
        if (t.isEmpty()) return
        punishments.add(0, Punishment(newId(), lang, t))
        savePunishments()
    }

    fun updatePunishment(id: String, text: String) {
        val i = punishments.indexOfFirst { it.id == id }
        if (i < 0) return
        val t = text.replace('\n', ' ').trim()
        if (t.isEmpty()) return
        punishments[i] = punishments[i].copy(text = t)
        savePunishments()
    }

    fun deletePunishment(id: String) {
        punishments.removeAll { it.id == id }
        savePunishments()
    }

    fun restoreDefaultPunishments() {
        val have = punishments.map { it.id }.toSet()
        val missing = Seeds.punishments().filter { it.lang == lang && it.id !in have }
        punishments.addAll(missing)
        savePunishments()
    }

    // ================= game flow =================

    fun start(m: GameMode) {
        mode = m
        used.clear()
        if (m == GameMode.CLASSIC) {
            if (names.size < 2) return
            bag.clear()
            lastPlayer = null
            choice = null
            prompt = null
            screen = Screen.PLAYING
            pickNext()
        } else {
            everyoneCount = 0
            everyoneQuestion = null
            screen = Screen.EVERYONE
            nextEveryone()
        }
    }

    fun pickNext() {
        if (spinning || names.isEmpty()) return
        viewModelScope.launch {
            spinning = true
            choice = null
            prompt = null

            if (bag.isEmpty()) refillBag()
            val next = bag.removeFirst()

            // Slot-machine effect that slows down before landing on the chosen player.
            repeat(14) { step ->
                spinDisplay = names.random()
                sound.play(Sfx.TICK)
                delay(60L + step * 14L)
            }
            currentPlayer = next
            lastPlayer = next
            spinning = false
            sound.play(Sfx.PICK)
        }
    }

    fun choose(c: Choice) {
        choice = c
        prompt = drawQuestion(c, null)
        sound.play(Sfx.SELECT)
    }

    fun newPrompt() {
        val c = choice ?: return
        prompt = drawQuestion(c, prompt?.id)
        sound.play(Sfx.TAP)
    }

    fun nextEveryone() {
        val q = drawQuestion(Choice.TRUTH, everyoneQuestion?.id)
        everyoneQuestion = q
        if (q != null) everyoneCount += 1
        sound.play(Sfx.SELECT)
    }

    // ================= internals =================

    private fun poolFor(type: Choice): List<Question> = questions.filter {
        it.lang == lang &&
            it.type == type &&
            it.category !in excludedCats &&
            it.difficulty !in excludedDiffs
    }

    /** Random question that matches the filters; no repeats until the whole pool has been used. */
    private fun drawQuestion(type: Choice, avoidId: String?): Question? {
        val pool = poolFor(type)
        if (pool.isEmpty()) return null
        var fresh = pool.filter { it.id !in used }
        if (fresh.isEmpty()) {
            used.removeAll(pool.map { it.id }.toSet())
            fresh = pool.filter { it.id != avoidId }.ifEmpty { pool }
        }
        val q = fresh.random()
        used.add(q.id)
        return q
    }

    private fun refillBag() {
        val shuffled = names.shuffled().toMutableList()
        // Avoid the same person going twice in a row when a new round starts.
        if (shuffled.size > 1 && shuffled.first() == lastPlayer) {
            val last = shuffled.lastIndex
            val tmp = shuffled[0]
            shuffled[0] = shuffled[last]
            shuffled[last] = tmp
        }
        bag.addAll(shuffled)
    }

    // ================= saving / loading =================

    private fun saveNames() {
        prefs.edit().putString("names", JSONArray(names.toList()).toString()).apply()
    }

    private fun saveCategories() {
        prefs.edit().putString("customCats", JSONArray(customCategories.toList()).toString()).apply()
    }

    private fun saveFilters() {
        prefs.edit()
            .putString("exCats", JSONArray(excludedCats.toList()).toString())
            .putString("exDiffs", JSONArray(excludedDiffs.map { it.name }).toString())
            .apply()
    }

    private fun saveQuestions() {
        val arr = JSONArray()
        questions.forEach { q ->
            arr.put(
                JSONObject()
                    .put("id", q.id)
                    .put("l", q.lang.name)
                    .put("t", q.type.name)
                    .put("c", q.category)
                    .put("d", q.difficulty.name)
                    .put("x", q.text)
            )
        }
        prefs.edit().putString("questions_v2", arr.toString()).apply()
    }

    private fun savePunishments() {
        val arr = JSONArray()
        punishments.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("l", p.lang.name)
                    .put("x", p.text)
            )
        }
        prefs.edit().putString("punishments_v2", arr.toString()).apply()
    }

    private fun readStrings(key: String): List<String> {
        val out = ArrayList<String>()
        runCatching {
            val arr = JSONArray(prefs.getString(key, "[]"))
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        }
        return out
    }

    private fun load() {
        lang = prefs.getString("lang", null)
            ?.let { saved -> Lang.values().firstOrNull { it.name == saved } }
            ?: if (Locale.getDefault().language == "fa") Lang.FA else Lang.EN

        themeMode = prefs.getString("theme", null)
            ?.let { saved -> ThemeMode.values().firstOrNull { it.name == saved } }
            ?: ThemeMode.SYSTEM

        soundOn = prefs.getBoolean("sound", true)
        sound.enabled = soundOn

        names.addAll(readStrings("names"))
        customCategories.addAll(readStrings("customCats"))
        excludedCats = readStrings("exCats").toSet()
        excludedDiffs = readStrings("exDiffs")
            .mapNotNull { n -> Difficulty.values().firstOrNull { it.name == n } }
            .toSet()

        loadQuestions()
        loadPunishments()
    }

    private fun loadQuestions() {
        val raw = prefs.getString("questions_v2", null)
        if (raw == null) {
            // First run of this version: start from the built-in set, and keep any questions
            // the user added in the previous version.
            questions.addAll(Seeds.questions())
            runCatching {
                val old = JSONArray(prefs.getString("custom", "[]"))
                for (i in 0 until old.length()) {
                    val o = old.getJSONObject(i)
                    questions.add(
                        0,
                        Question(
                            newId(),
                            Lang.valueOf(o.getString("l")),
                            Choice.valueOf(o.getString("c")),
                            "general",
                            Difficulty.MEDIUM,
                            o.getString("t")
                        )
                    )
                }
            }
            saveQuestions()
        } else {
            runCatching {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    questions.add(
                        Question(
                            o.getString("id"),
                            Lang.valueOf(o.getString("l")),
                            Choice.valueOf(o.getString("t")),
                            o.getString("c"),
                            Difficulty.valueOf(o.getString("d")),
                            o.getString("x")
                        )
                    )
                }
            }
        }
    }

    private fun loadPunishments() {
        val raw = prefs.getString("punishments_v2", null)
        if (raw == null) {
            punishments.addAll(Seeds.punishments())
            savePunishments()
        } else {
            runCatching {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    punishments.add(
                        Punishment(o.getString("id"), Lang.valueOf(o.getString("l")), o.getString("x"))
                    )
                }
            }
        }
    }

    override fun onCleared() {
        sound.release()
        super.onCleared()
    }
}
