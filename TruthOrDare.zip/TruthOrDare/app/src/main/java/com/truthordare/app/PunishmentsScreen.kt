package com.truthordare.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

@Composable
fun PunishmentsScreen(vm: GameViewModel, s: Strings) {
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Punishment?>(null) }
    var deleting by remember { mutableStateOf<Punishment?>(null) }
    val list = vm.punishments.filter { it.lang == vm.lang }
    val addNew = {
        vm.addPunishment(input)
        input = ""
        vm.sfx(Sfx.TAP)
    }

    Column(modifier = Modifier.fillMaxSize().screenPadding()) {
        TopBar(title = s.punishmentsTitle, onBack = { vm.goBack() })
        Text(
            s.punishmentsHint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text(s.newPunishmentLabel) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { addNew() })
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { addNew() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.Add, contentDescription = s.addButton)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            s.punishmentsCount(list.size),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (list.isEmpty()) {
                item {
                    Text(
                        s.noneYet,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            items(list, key = { it.id }) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            p.text,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyLarge
                        )
                        IconButton(onClick = { editing = p }) {
                            Icon(Icons.Filled.Edit, contentDescription = s.edit)
                        }
                        IconButton(onClick = { deleting = p }) {
                            Icon(Icons.Filled.Delete, contentDescription = s.delete)
                        }
                    }
                }
            }
            item {
                TextButton(
                    onClick = { vm.restoreDefaultPunishments() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(s.restorePunishments) }
            }
        }
    }

    editing?.let { p ->
        TextInputDialog(
            title = s.edit,
            label = s.newPunishmentLabel,
            initial = p.text,
            saveText = s.saveButton,
            cancelText = s.cancel,
            onSave = { vm.updatePunishment(p.id, it) },
            onDismiss = { editing = null }
        )
    }
    deleting?.let { p ->
        ConfirmDialog(
            title = s.deleteTitle,
            body = p.text,
            confirm = s.delete,
            cancel = s.cancel,
            onConfirm = {
                vm.deletePunishment(p.id)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
}
