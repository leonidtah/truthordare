package com.truthordare.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ClassicScreen(vm: GameViewModel, s: Strings) {
    val extra = LocalExtra.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .screenPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.backToSetup() }) { Text(s.editPlayers) }
            Text(s.playing(vm.names.size), style = MaterialTheme.typography.labelLarge)
        }

        Spacer(Modifier.weight(1f))

        val choice = vm.choice
        val q = vm.prompt

        when {
            vm.spinning -> {
                Text(s.picking, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                Text(
                    vm.spinDisplay,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            choice == null -> {
                Text(s.yourTurn, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    vm.currentPlayer,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(32.dp))
                Text(s.truthOrDare, style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ChoiceButton(s.truth, extra.truth) { vm.choose(Choice.TRUTH) }
                    ChoiceButton(s.dare, extra.dare) { vm.choose(Choice.DARE) }
                }
            }

            else -> {
                val color = if (choice == Choice.TRUTH) extra.truth else extra.dare
                val label = if (choice == Choice.TRUTH) s.truth else s.dare
                Text(
                    "${vm.currentPlayer} · $label",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
                PromptCard(text = q?.text ?: s.noQuestions, color = if (q != null) color else null)
                if (q != null) {
                    Spacer(Modifier.height(10.dp))
                    TagsRow(q, s)
                }
                Spacer(Modifier.height(20.dp))
                SecondaryButton(s.anotherOne, onClick = { vm.newPrompt() })
            }
        }

        Spacer(Modifier.weight(1f))

        if (!vm.spinning) {
            if (choice != null) {
                SecondaryButton(s.punishmentWheel, onClick = { vm.openWheel() })
                Spacer(Modifier.height(8.dp))
            }
            PrimaryButton(
                text = if (choice == null) s.skipTurn else s.doneNext,
                onClick = {
                    vm.sfx(Sfx.TAP)
                    vm.pickNext()
                }
            )
        }
    }
}

@Composable
fun EveryoneScreen(vm: GameViewModel, s: Strings) {
    val extra = LocalExtra.current
    val q = vm.everyoneQuestion

    Column(
        modifier = Modifier
            .fillMaxSize()
            .screenPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopBar(title = s.everyoneTitle, onBack = { vm.goBack() })

        Spacer(Modifier.weight(1f))

        if (q != null) {
            Text(
                s.questionNumber(vm.everyoneCount),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(12.dp))
        }
        PromptCard(text = q?.text ?: s.noQuestions, color = if (q != null) extra.truth else null)
        Spacer(Modifier.height(12.dp))
        if (q != null) {
            Text(
                s.everyoneHint,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            TagsRow(q, s)
        }

        Spacer(Modifier.weight(1f))

        SecondaryButton(s.punishmentWheel, onClick = { vm.openWheel() })
        Spacer(Modifier.height(8.dp))
        PrimaryButton(s.nextQuestion, onClick = { vm.nextEveryone() })
    }
}

@Composable
private fun PromptCard(text: String, color: Color?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = color ?: MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Text(
            text,
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Medium,
            color = if (color != null) Color.White else MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun TagsRow(q: Question, s: Strings) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        CategoryTag(s.cat(q.category))
        DifficultyTag(q.difficulty, s.diff(q.difficulty))
    }
}

@Composable
private fun RowScope.ChoiceButton(label: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .weight(1f)
            .height(72.dp),
        shape = RoundedCornerShape(22.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White)
    ) {
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}
